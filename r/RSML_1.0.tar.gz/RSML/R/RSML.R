#' Root system of a lupin plant in 2D
#' 
#' @docType data
#' @keywords datasets
#' @name lupin
#' @usage data(lupin)
NULL


#' Root system of a anagallis plant in 3D
#' 
#' @docType data
#' @keywords datasets
#' @name anagallis
#' @usage data(anagallis)
NULL


#' Root system of a maize plant in 3D
#' 
#' @docType data
#' @keywords datasets
#' @name maize
#' @usage data(maize)
NULL




